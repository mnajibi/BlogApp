export class Comment{
    author: string | undefined;
    comment: string | undefined;
    date: string | undefined;
    }